var ballX = 400;
var ballY = 300;
var ballSpeedX = 4;
var ballSpeedY = 4;

var playerX= 0;
var playerY= 250;
var oppX = 790;
var oppY = 250;

var playerScore = 0;
var oppScore = 0;



function setup() {
  createCanvas(800,600);
}

function draw() {
  background(0);
  ellipse(ballX, ballY, 20, 20);
  ballMove();
  rect(playerX, playerY, 10, 100);
  playerY = mouseY;
  rect(oppX, oppY, 10, 100);
  moveOpp();
  stroke(255);
  fill(255);
  text(playerScore, 100, 100);
  text(oppScore, 700, 100);

}

function ballMove() {
  ballX += ballSpeedX;
  ballY += ballSpeedY;
  if(ballX < 0) {
      resetBall();
      oppScore++;
  }
  if(ballX < 10 && ballY > playerY && ballY < playerY + 100){
    ballSpeedX *= -1;
  }  
  if(ballX > 790 && ballY > oppY && ballY < oppY + 100){
    ballSpeedX *= -1;
  }  
  
  if(ballX > width) {
      resetBall();
      playerScore++;
  }  
  if(ballY < 0) {
    ballSpeedY *= -1;
  }  
  if(ballY > height) {
    ballSpeedY *= -1;
  }  
}

function resetBall(){
  ballX = width/2;
  ballY = height/2;
  ballSpeedX *= -1;
  
}

function moveOpp(){
  var middle = oppY + 190/2;
  if(middle< ballY+25){
    oppY += 4;
  }  
  if(middle > ballY-25){
    oppY -= 4;
  }  
    
}  
  
